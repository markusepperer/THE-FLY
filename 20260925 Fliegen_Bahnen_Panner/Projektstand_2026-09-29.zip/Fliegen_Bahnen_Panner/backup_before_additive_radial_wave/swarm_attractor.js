autowatch=1; inlets=37; outlets=3;
var namespace=(jsarguments.length>1)?String(jsarguments[1]):"default";
var leaders=new Global("MS_SwarmLeaders_"+namespace);
var voiceId=0, voiceCount=1, swarmCount=1, oldSwarmCount=1;
var densities=[0,0,0,0,0], grids=[0,0,0,0,0];
var densityCurrent=[0,0,0,0,0], gridCurrent=[0,0,0,0,0], morphTimes=[0,0,0,0,0];
var orbitTempos=[0,0,0,0,0], ringModes=[0,0,0,0,0], ringSpreads=[0,0,0,0,0];
var pulseInner=[0,0,0,0,0],pulseOuter=[100,100,100,100,100],pulseTempo=[0,0,0,0,0],pulsePhaseSpread=[0,0,0,0,0],pulseTempoSpread=[0,0,0,0,0];
var pulseInnerNow=[0,0,0,0,0],pulseOuterNow=[100,100,100,100,100],pulsePhaseNow=[0,0,0,0,0],pulseTempoSpreadNow=[0,0,0,0,0];
var pulsePhaseState=[0,0,0,0,0],pulseSpeedNow=[0,0,0,0,0],pulseActiveNow=[0,0,0,0,0],pulseTimes=[0,0,0,0,0];
var pulseSyncEpoch=[0,0,0,0,0],pulseSyncStart=[0,0,0,0,0];
var snakeEnabled=[0,0,0,0,0],snakeSpacing=[20,20,20,20,20],snakeSpacingSound=[20,20,20,20,20],snakeMix=[0,0,0,0,0],snakeTimes=[0,0,0,0,0];
var historySize=1024,lastLeaderGroup=0;
var alignmentTarget=[0,0,0,0,0],alignmentSpatial=[0,0,0,0,0],alignmentSound=[0,0,0,0,0],alignmentTimes=[0,0,0,0,0];
var alignmentOffsetX=[0,0,0,0,0],alignmentOffsetY=[0,0,0,0,0],alignmentCapture=[0,0,0,0,0];
var escapeStrength=[50,50,50,50,50],escapeReturn=[2,2,2,2,2],escapeStart=[0,0,0,0,0],escapePending=[0,0,0,0,0],escapeDX=[0,0,0,0,0],escapeDY=[0,0,0,0,0];
var escapeAttack=[.12,.12,.12,.12,.12],escapeDuration=[2,2,2,2,2];
var waveModes=[0,0,0,0,0],waveTypes=[0,0,0,0,0],waveRuns=[0,0,0,0,0];
var waveAmplitudes=[25,25,25,25,25],waveLengths=[50,50,50,50,50],waveSpeeds=[.2,.2,.2,.2,.2],waveWidths=[20,20,20,20,20];
var wavePhase=[0,0,0,0,0],waveElapsed=[0,0,0,0,0],waveTimes=[0,0,0,0,0];
var waveRawX=0,waveRawY=0,waveRawReady=0;
// Portal is a standalone spatial stream. mode: -1 sink, 0 off, 1 source.
var portalMode=0,portalX=.5,portalY=.5,portalDirection=0,portalWidth=45,portalSpeed=.25,portalDeviation=25;
var portalMix=0,portalMixTime=0,portalLastTime=0,portalPhase=0,portalCycle=-1,portalAngleOffset=0,portalLatchedAngle=0,portalLatchedX=.5,portalLatchedY=.5,portalTravelDistance=.5,portalFunnel=.18;
var portalSoundX=.5,portalSoundY=.5,portalSoundTime=0,portalSoundReady=0;
// Every ring owns a continuous phase and smoothed angular speed. Parameter
// changes therefore alter only future motion and can never jump position.
var ringPhase={}, ringSpeed={}, ringTime={};
var lastX=0.5,lastY=0.5,lastSoundX=0.5,lastSoundY=0.5;
var transitionX=0.5,transitionY=0.5,transitionSoundX=0.5,transitionSoundY=0.5,transitionStart=0,transitionMs=500;
function clamp(v,a,b){return Math.max(a,Math.min(b,Number(v)));} function now(){return new Date().getTime();} function setPortalX(v){var nv=clamp(v,0,1);if(Math.abs(nv-portalX)>1e-9)outlet(2,"rebase");portalX=nv;} function setPortalY(v){var nv=clamp(v,0,1);if(Math.abs(nv-portalY)>1e-9)outlet(2,"rebase");portalY=nv;}
function msg_int(v){if(inlet===1)voiceId=Math.max(0,Math.floor(v));else if(inlet===2)setAll(densities,v);else if(inlet===3)setAll(grids,v);else if(inlet===4)voiceCount=Math.max(1,Math.floor(clamp(v,1,50)));else if(inlet===5)setswarms(v);else if(inlet===22)portalMode=Math.floor(clamp(v,-1,1));else if(inlet===23)setPortalX(v);else if(inlet===24)setPortalY(v);else if(inlet===25)portalDirection=((Number(v)%360)+360)%360;else if(inlet===26)portalWidth=clamp(v,0,360);else if(inlet===27)portalSpeed=clamp(v,0,20);else if(inlet===28)portalDeviation=clamp(v,0,100);else if(inlet===29)emitPortalOrigin();}
function msg_float(v){msg_int(v);} function setAll(a,v){v=clamp(v,0,100)*.01;for(var i=1;i<=4;i++)a[i]=v;}
function bang(){if(inlet===29)emitPortalOrigin();}
function emitPortalOrigin(){if(portalMode===0)return;var t=now();portalMix=1;portalMixTime=t;portalLastTime=t;portalPhase=-portalHash(voiceId*7.31);portalCycle=-1;portalAngleOffset=0;portalLatchedAngle=portalDirection*Math.PI/180.;portalLatchedX=portalX;portalLatchedY=portalY;portalTravelDistance=Math.max(.05,portalEdgeDistance(portalLatchedX,portalLatchedY,Math.cos(portalLatchedAngle),Math.sin(portalLatchedAngle)));portalSoundX=portalX;portalSoundY=portalY;portalSoundTime=t;portalSoundReady=1;lastX=portalX;lastY=portalY;lastSoundX=portalX;lastSoundY=portalY;outlet(2,"reset");outlet(0,portalX,portalY);outlet(1,portalX,portalY);}
function list(){var a=arrayfromargs(arguments); if(inlet===6){if(a.length>1)densities[Math.floor(clamp(a[0],1,4))]=clamp(a[1],0,100)*.01;return;} if(inlet===7){if(a.length>1)grids[Math.floor(clamp(a[0],1,4))]=clamp(a[1],0,100)*.01;return;} if(inlet===8){if(a.length>1)orbitTempos[Math.floor(clamp(a[0],1,4))]=clamp(a[1],-10,10);return;} if(inlet===9){if(a.length>1)ringModes[Math.floor(clamp(a[0],1,4))]=Math.floor(clamp(a[1],0,2));return;} if(inlet===10){if(a.length>1)ringSpreads[Math.floor(clamp(a[0],1,4))]=clamp(a[1],0,100)*.01;return;} if(inlet>=11&&inlet<=15){if(a.length>1){var pg=Math.floor(clamp(a[0],1,4)),pv=Number(a[1]);if(inlet===11)pulseInner[pg]=clamp(pv,0,100);else if(inlet===12)pulseOuter[pg]=clamp(pv,0,100);else if(inlet===13)pulseTempo[pg]=clamp(pv,0,10);else if(inlet===14)pulsePhaseSpread[pg]=clamp(pv,0,100);else {pulseTempoSpread[pg]=clamp(pv,0,100);if(a.length>2&&pulseTempoSpread[pg]===0){pulseSyncEpoch[pg]=Number(a[2]);pulseSyncStart[pg]=now();}else if(pulseTempoSpread[pg]>0)pulseSyncEpoch[pg]=0;}}return;} if(inlet===16){if(a.length>1)snakeEnabled[Math.floor(clamp(a[0],1,4))]=Number(a[1])!==0?1:0;return;} if(inlet===17){if(a.length>1)snakeSpacing[Math.floor(clamp(a[0],1,4))]=clamp(a[1],0,100);return;} if(inlet===18){if(a.length>1){var ag=Math.floor(clamp(a[0],1,4)),av=clamp(a[1],0,100)*.01;if(alignmentTarget[ag]===0&&av>0)alignmentCapture[ag]=1;alignmentTarget[ag]=av;}return;} if(inlet===19){if(a.length>0){var eg=Math.floor(clamp(a[0],1,4));escapePending[eg]=1;}return;} if(inlet===20){if(a.length>1)escapeStrength[Math.floor(clamp(a[0],1,4))]=clamp(a[1],0,100);return;} if(inlet===21){if(a.length>1)escapeReturn[Math.floor(clamp(a[0],1,4))]=clamp(a[1],.2,10);return;}
if(inlet===22){portalMode=Math.floor(clamp(a[0],-1,1));return;}
if(inlet===23){setPortalX(a[0]);return;}
if(inlet===24){setPortalY(a[0]);return;}
if(inlet===25){portalDirection=((Number(a[0])%360)+360)%360;return;}
if(inlet===26){portalWidth=clamp(a[0],0,360);return;}
if(inlet===27){portalSpeed=clamp(a[0],0,20);return;}
if(inlet===28){portalDeviation=clamp(a[0],0,100);return;}
if(inlet>=30&&inlet<=36){if(a.length>1){var wg=Math.floor(clamp(a[0],1,4)),wv=Number(a[1]);if(inlet===30)waveModes[wg]=Math.floor(clamp(wv,0,2));else if(inlet===31)waveTypes[wg]=Math.floor(clamp(wv,0,1));else if(inlet===32){waveRuns[wg]=Math.floor(clamp(wv,0,2));if(waveRuns[wg]===1)waveElapsed[wg]=0;}else if(inlet===33)waveAmplitudes[wg]=clamp(wv,0,100);else if(inlet===34)waveLengths[wg]=clamp(wv,1,100);else if(inlet===35)waveSpeeds[wg]=clamp(wv,0,2);else waveWidths[wg]=clamp(wv,1,100);}return;}
if(inlet!==0||a.length<2)return; process(Number(a[0]),Number(a[1]));}
function setswarms(v){v=Math.max(1,Math.min(4,Math.floor(Number(v))));if(v!==swarmCount){oldSwarmCount=swarmCount;swarmCount=v;transitionX=lastX;transitionY=lastY;transitionSoundX=lastSoundX;transitionSoundY=lastSoundY;transitionStart=now();}}
function groupFor(id,c){return ((id-1)%c)+1;} function localIndex(id,c){return Math.floor((id-1)/c)+1;} function members(g,c,n){return n<g?0:Math.floor((n-g)/c)+1;}
function ringDirection(g,ring,R){var rm=ringModes[g];if(rm===1&&ring%2===0)return -1;if(rm===2&&ring>Math.ceil(R*.5))return -1;return 1;}
function organicBias(g){var t=now()/1000.,p=g*1.731;return clamp((Math.sin(t*.263+p)+.55*Math.sin(t*.151+p*1.7)+.25*Math.sin(t*.087+p*.63))/1.8*1.35,-1,1);}
function ringSpeedFactor(g,ring,R){if(R<=1)return 1;var amount=ringSpreads[g]*organicBias(g),sum=0;for(var q=1;q<=R;q++){var qn=(q-1)/(R-1);sum+=Math.pow(4,amount*(1-2*qn));}var rn=(ring-1)/(R-1),raw=Math.pow(4,amount*(1-2*rn));return raw/(sum/R);}
function advanceRing(g,ring,R){var key=g+":"+ring,t=now(),last=ringTime[key]||t,dt=clamp((t-last)/1000.,0,.1);ringTime[key]=t;var target=orbitTempos[g]*ringDirection(g,ring,R)*ringSpeedFactor(g,ring,R),cur=Number(ringSpeed[key])||0,a=1-Math.exp(-dt/.65);cur+=(target-cur)*a;ringSpeed[key]=cur;var ph=Number(ringPhase[key])||0;ph+=cur*.30*dt;ringPhase[key]=ph;return ph;}
function formation(localId,n,g){if(localId<=1||n<=1)return [.5,.5];var f=n-1,R=1;while(3*R*(R+1)<f)R++;var idx=localId-2,prev=0,end=0,ring=1,den=R*(R+1);for(ring=1;ring<=R;ring++){end=Math.round(f*ring*(ring+1)/den);if(idx<end)break;prev=end;}var used=Math.max(1,end-prev),pos=idx-prev,rad=.4*ring/R,off=(ring%2===0)?Math.PI/used:0,ang=-Math.PI*.5+off+2*Math.PI*pos/used;ang+=advanceRing(g,ring,R);return [.5+Math.cos(ang)*rad,.5+Math.sin(ang)*rad];}
function smoothMorph(g){var t=now(),last=morphTimes[g];if(!last){morphTimes[g]=t;densityCurrent[g]=densities[g];gridCurrent[g]=grids[g];return;}var dt=clamp((t-last)/1000.,0,.1);morphTimes[g]=t;var a=1-Math.exp(-dt/1.5);densityCurrent[g]+=(densities[g]-densityCurrent[g])*a;gridCurrent[g]+=(grids[g]-gridCurrent[g])*a;}
function voiceVariation(id){var z=Math.sin(id*12.9898+78.233)*43758.5453;return 2*(z-Math.floor(z)) - 1;}
function pulseScale(g,local,n){var t=now(),last=pulseTimes[g]||t,dt=clamp((t-last)/1000.,0,.1);pulseTimes[g]=t;var a=1-Math.exp(-dt/.45);pulseInnerNow[g]+=(pulseInner[g]-pulseInnerNow[g])*a;pulseOuterNow[g]+=(pulseOuter[g]-pulseOuterNow[g])*a;pulsePhaseNow[g]+=(pulsePhaseSpread[g]-pulsePhaseNow[g])*a;pulseTempoSpreadNow[g]+=(pulseTempoSpread[g]-pulseTempoSpreadNow[g])*a;pulseActiveNow[g]+=((pulseTempo[g]>0?1:0)-pulseActiveNow[g])*a;var variation=voiceVariation(voiceId),tempoFactor=Math.pow(2,(pulseTempoSpreadNow[g]/100)*variation),targetSpeed=pulseTempo[g]*tempoFactor,sa=1-Math.exp(-dt/.65);pulseSpeedNow[g]+=(targetSpeed-pulseSpeedNow[g])*sa;pulsePhaseState[g]+=pulseSpeedNow[g]*(2*Math.PI/5)*dt;if(pulseSyncEpoch[g]>0){var desired=((t-pulseSyncEpoch[g])/1000.)*pulseTempo[g]*(2*Math.PI/5),diff=desired-pulsePhaseState[g];diff=Math.atan2(Math.sin(diff),Math.cos(diff));pulsePhaseState[g]+=diff*(1-Math.exp(-dt/1.2));if(t-pulseSyncStart[g]>3000)pulseSyncEpoch[g]=0;}var offset=(pulsePhaseNow[g]/100)*2*Math.PI*((Math.max(1,local)-1)/Math.max(1,n)),wave=.5+.5*Math.sin(pulsePhaseState[g]+offset),lo=Math.min(pulseInnerNow[g],pulseOuterNow[g])*.01,hi=Math.max(pulseInnerNow[g],pulseOuterNow[g])*.01;var pulsed=lo+(hi-lo)*wave;return 1+pulseActiveNow[g]*(pulsed-1);}
function applyPulse(point,lx,ly,scale,valid){if(!valid)return point;return[lx+(point[0]-lx)*scale,ly+(point[1]-ly)*scale];}

function historyKey(prefix,g,i){return prefix+g+"_"+i;}
function resetHistory(g,x,y){leaders["hh"+g]=0;leaders["hn"+g]=1;leaders["htotal"+g]=0;leaders[historyKey("hx",g,0)]=x;leaders[historyKey("hy",g,0)]=y;leaders[historyKey("hc",g,0)]=0;leaders["hvalid"+g]=1;}
function recordHistory(g,x,y){if(!leaders["hvalid"+g]){resetHistory(g,x,y);return;}var h=Math.floor(Number(leaders["hh"+g])||0),px=Number(leaders[historyKey("hx",g,h)]),py=Number(leaders[historyKey("hy",g,h)]);if(!isFinite(px)||!isFinite(py)){resetHistory(g,x,y);return;}var dx=x-px,dy=y-py,dist=Math.sqrt(dx*dx+dy*dy);if(dist<.0005)return;var nh=(h+1)%historySize,total=(Number(leaders["htotal"+g])||0)+dist,n=Math.min(historySize,Math.floor(Number(leaders["hn"+g])||1)+1);leaders[historyKey("hx",g,nh)]=x;leaders[historyKey("hy",g,nh)]=y;leaders[historyKey("hc",g,nh)]=total;leaders["hh"+g]=nh;leaders["hn"+g]=n;leaders["htotal"+g]=total;}
function trailPoint(g,distance){if(!leaders["hvalid"+g])return null;var h=Math.floor(Number(leaders["hh"+g])||0),n=Math.floor(Number(leaders["hn"+g])||1),newer=h,nc=Number(leaders[historyKey("hc",g,newer)])||0,target=nc-distance;for(var k=1;k<n;k++){var older=(h-k+historySize)%historySize,oc=Number(leaders[historyKey("hc",g,older)])||0;if(oc<=target){var den=nc-oc,u=den>0?(target-oc)/den:0,ox=Number(leaders[historyKey("hx",g,older)]),oy=Number(leaders[historyKey("hy",g,older)]),nx=Number(leaders[historyKey("hx",g,newer)]),ny=Number(leaders[historyKey("hy",g,newer)]);return[ox+(nx-ox)*u,oy+(ny-oy)*u];}newer=older;nc=oc;}return[Number(leaders[historyKey("hx",g,newer)]),Number(leaders[historyKey("hy",g,newer)])];}
function updateSnakeMix(g){var t=now(),last=snakeTimes[g]||t,dt=clamp((t-last)/1000.,0,.1);snakeTimes[g]=t;snakeMix[g]+=(snakeEnabled[g]-snakeMix[g])*(1-Math.exp(-dt/1.0));snakeSpacingSound[g]+=(snakeSpacing[g]-snakeSpacingSound[g])*(1-Math.exp(-dt/1.5));return snakeMix[g];}
function applySnake(point,target,mix){if(!target||!isFinite(target[0])||!isFinite(target[1]))return point;return[point[0]+(target[0]-point[0])*mix,point[1]+(target[1]-point[1])*mix];}

function updateAlignment(g,x,y,lx,ly,valid){var t=now(),last=alignmentTimes[g]||t,dt=clamp((t-last)/1000.,0,.1);alignmentTimes[g]=t;if(alignmentCapture[g]&&valid){alignmentOffsetX[g]=x-lx;alignmentOffsetY[g]=y-ly;alignmentCapture[g]=0;}alignmentSpatial[g]+=(alignmentTarget[g]-alignmentSpatial[g])*(1-Math.exp(-dt/.45));alignmentSound[g]+=(alignmentTarget[g]-alignmentSound[g])*(1-Math.exp(-dt/1.5));}
function alignedPoint(x,y,lx,ly,mix,g,valid){if(!valid||voiceId===g)return[x,y];var tx=lx+alignmentOffsetX[g],ty=ly+alignmentOffsetY[g];return[x+(tx-x)*mix,y+(ty-y)*mix];}

function applyEscape(point,g,lx,ly,valid){if(!valid)return point;var t=now();if(escapePending[g]){var dx=point[0]-lx,dy=point[1]-ly,len=Math.sqrt(dx*dx+dy*dy),radial=len;if(len<.0001){var fallback=voiceId*2.399963229728653;dx=Math.cos(fallback);dy=Math.sin(fallback);len=1;}var baseAngle=Math.atan2(dy,dx),angleJitter=(Math.random()-.5)*1.15,angle=baseAngle+angleJitter,rDelay=Math.random(),rAttack=Math.random(),rMag=Math.random(),rRare=Math.random(),rReturn=Math.random(),delay=.015+.8*rDelay*rDelay+.3*Math.min(1,radial/.6)*Math.random(),attack=.035+.52*rAttack*rAttack,magFactor;if(rRare<.2)magFactor=1.5+1.3*Math.random();else magFactor=.18+1.12*Math.pow(rMag,1.7);var mag=Math.min(.95,escapeStrength[g]*.0035*magFactor);escapeDX[g]=Math.cos(angle)*mag;escapeDY[g]=Math.sin(angle)*mag;escapeAttack[g]=attack;escapeDuration[g]=Math.max(.2,escapeReturn[g]*(.45+1.35*rReturn));escapeStart[g]=t+delay*1000;escapePending[g]=0;}if(!escapeStart[g])return point;var elapsed=(t-escapeStart[g])/1000.;if(elapsed<0)return point;var attack=escapeAttack[g],env;if(elapsed<attack){var au=elapsed/attack;env=.5-.5*Math.cos(Math.PI*au);}else{var ru=(elapsed-attack)/escapeDuration[g];if(ru>=1){escapeStart[g]=0;return point;}env=.5+.5*Math.cos(Math.PI*ru);}return[point[0]+escapeDX[g]*env,point[1]+escapeDY[g]*env];}

// Continuous wave phase plus parameter morphing. GUI motion is subtracted
// only from the acoustic coordinate derivative, not from actual wave motion.
var waveSmooth=[],waveBefore=[],waveBiasX=[0,0,0,0,0],waveBiasY=[0,0,0,0,0];
function waveState(g){var weights=[0,0,0,0,0,0];weights[waveModes[g]*2+waveTypes[g]]=1;return {amp:waveAmplitudes[g],len:waveLengths[g],speed:waveSpeeds[g],width:waveWidths[g],weights:weights};}
function copyWaveState(p){return {amp:p.amp,len:p.len,speed:p.speed,width:p.width,weights:p.weights.slice(0)};}
function updateWave(g,baseMoved){
 var t=now(),last=waveTimes[g]||t,dt=clamp((t-last)/1000.,0,.1);waveTimes[g]=t;
 if(!waveSmooth[g])waveSmooth[g]=waveState(g);
 var p=waveSmooth[g];
 if(baseMoved){wavePhase[g]+=2*Math.PI*p.speed/(.04+.96*p.len*.01)*dt;if(waveRuns[g]===1)waveElapsed[g]+=p.speed*dt;}
 waveBefore[g]=copyWaveState(p);
 var target=waveState(g),a=1-Math.exp(-dt/.35);
 p.amp+=(target.amp-p.amp)*a;p.len+=(target.len-p.len)*a;p.speed+=(target.speed-p.speed)*a;p.width+=(target.width-p.width)*a;
 for(var i=0;i<6;i++)p.weights[i]+=(target.weights[i]-p.weights[i])*a;
}
function waveOffset(point,g,lx,ly,valid,p){
 if(waveRuns[g]===0||snakeEnabled[g])return [0,0];
 var dx=point[0]-(valid?lx:.5),dy=point[1]-(valid?ly:.5),rad=Math.sqrt(dx*dx+dy*dy),len=.04+.96*p.len*.01,ox=0,oy=0;
 for(var k=0;k<6;k++){
  var mode=Math.floor(k/2),type=k%2,q=mode===0?point[0]:mode===1?point[1]:rad,value=0;
  if(waveRuns[g]===2)value=Math.sin(2*Math.PI*q/len-wavePhase[g]);
  else{var width=.02+.58*p.width*.01,d=q-waveElapsed[g];if(Math.abs(d)<=width)value=Math.cos(2*Math.PI*d/len)*(.5+.5*Math.cos(Math.PI*d/width));}
  var vx=0,vy=0;if(mode===0){vx=type;vy=1-type;}else if(mode===1){vx=1-type;vy=type;}else if(rad>.0001){if(type){vx=dx/rad;vy=dy/rad;}else{vx=-dy/rad;vy=dx/rad;}}
  var amount=p.weights[k]*p.amp*.0028*value;ox+=vx*amount;oy+=vy*amount;
 }
 return [ox,oy];
}
function waveDisplace(point,g,lx,ly,valid,isSound){
 var after=waveOffset(point,g,lx,ly,valid,waveSmooth[g]);
 if(isSound){var before=waveOffset(point,g,lx,ly,valid,waveBefore[g]);waveBiasX[g]+=before[0]-after[0];waveBiasY[g]+=before[1]-after[1];return [point[0]+after[0]+waveBiasX[g],point[1]+after[1]+waveBiasY[g]];}
 return [point[0]+after[0],point[1]+after[1]];
}

function portalHash(seed){var q=Math.sin(seed*12.9898+78.233)*43758.5453;return q-Math.floor(q);}
function portalEdgeDistance(px,py,dx,dy){var d=1e9,v;if(dx>1e-7){v=(1-px)/dx;if(v>0)d=Math.min(d,v);}else if(dx<-1e-7){v=(0-px)/dx;if(v>0)d=Math.min(d,v);}if(dy>1e-7){v=(1-py)/dy;if(v>0)d=Math.min(d,v);}else if(dy<-1e-7){v=(0-py)/dy;if(v>0)d=Math.min(d,v);}return isFinite(d)?d:0;}
function updatePortalPhase(){var t=now(),last=portalLastTime||t,dt=clamp((t-last)/1000.,0,.1);portalLastTime=t;var distanceScale=.5/clamp(portalTravelDistance,.05,1.5);portalPhase+=portalSpeed*dt*distanceScale;var target=portalMode===0?0:1,mt=portalMixTime||t,mdt=clamp((t-mt)/1000.,0,.1);portalMixTime=t;portalMix+=(target-portalMix)*(1-Math.exp(-mdt/.35));}
function portalPoint(x,y){updatePortalPhase();var raw=portalPhase+portalHash(voiceId*7.31),cycle=Math.floor(raw),u=raw-cycle,travel=portalMode<0?1-u:u;if(cycle!==portalCycle){var recycling=portalCycle!==-1;portalCycle=cycle;portalAngleOffset=portalHash(voiceId*37.17+cycle*19.73)-.5;portalLatchedAngle=(portalDirection+portalAngleOffset*portalWidth)*Math.PI/180.;portalLatchedX=portalX;portalLatchedY=portalY;outlet(2,recycling?"rebase":"reset");}if(travel<=portalFunnel){portalLatchedAngle=(portalDirection+portalAngleOffset*portalWidth)*Math.PI/180.;portalLatchedX=portalX;portalLatchedY=portalY;}var dx=Math.cos(portalLatchedAngle),dy=Math.sin(portalLatchedAngle),edge=portalEdgeDistance(portalLatchedX,portalLatchedY,dx,dy);if(travel<=portalFunnel)portalTravelDistance=Math.max(.05,edge);var baseX=portalLatchedX+dx*edge*travel,baseY=portalLatchedY+dy*edge*travel,devAmount=Math.pow(portalDeviation*.01,.82),organic=devAmount*Math.pow(Math.max(0,travel),2),sideSeed=2*portalHash(voiceId*53.71+cycle*11.19)-1,sideWave=Math.sin((travel*1.35+portalHash(voiceId*17.13))*Math.PI*2),side=.42*organic*(.68*sideSeed+.32*sideWave),microX=(x-.5)*.75*organic-dy*side,microY=(y-.5)*.75*organic+dx*side;return[baseX+microX,baseY+microY];}
function portalSoundPoint(pp){portalSoundX=pp[0];portalSoundY=pp[1];portalSoundTime=now();portalSoundReady=1;return pp;}
function applyPortal(point,x,y,isSound){if(portalMix<.0001&&portalMode===0){if(isSound)portalSoundReady=0;return point;}var pp=portalPoint(x,y);if(isSound)pp=portalSoundPoint(pp);var m=portalMix;return[point[0]+(pp[0]-point[0])*m,point[1]+(pp[1]-point[1])*m];}
function mapFormation(x,y,fp,gr,den,lx,ly,leaderValid){var fx=x*(1-gr)+(fp[0]+(x-.5)*.05)*gr,fy=y*(1-gr)+(fp[1]+(y-.5)*.05)*gr;if(!leaderValid)return[fx,fy];var sc=1-den;return[lx+(fx-lx)*sc,ly+(fy-ly)*sc];}
function compute(x,y,c){var baseMoved=!waveRawReady||Math.abs(x-waveRawX)>1e-7||Math.abs(y-waveRawY)>1e-7;waveRawX=x;waveRawY=y;waveRawReady=1;var g=groupFor(voiceId,c),local=localIndex(voiceId,c),n=members(g,c,voiceCount);smoothMorph(g);if(local===1){leaders["x"+g]=x;leaders["y"+g]=y;leaders["v"+g]=1;if(lastLeaderGroup!==g){resetHistory(g,x,y);lastLeaderGroup=g;}recordHistory(g,x,y);}var fp=formation(local,n,g),lx=Number(leaders["x"+g]),ly=Number(leaders["y"+g]),valid=leaders["v"+g]&&isFinite(lx)&&isFinite(ly);updateAlignment(g,x,y,lx,ly,valid);var alignedSpatial=alignedPoint(x,y,lx,ly,alignmentSpatial[g],g,valid),alignedAcoustic=alignedPoint(x,y,lx,ly,alignmentSound[g],g,valid);var spatial=mapFormation(alignedSpatial[0],alignedSpatial[1],fp,grids[g],densities[g],lx,ly,valid);var acoustic=mapFormation(alignedAcoustic[0],alignedAcoustic[1],fp,gridCurrent[g],densityCurrent[g],lx,ly,valid);var ps=pulseScale(g,local,n);spatial=applyPulse(spatial,lx,ly,ps,valid);acoustic=applyPulse(acoustic,lx,ly,ps,valid);spatial=applyEscape(spatial,g,lx,ly,valid);acoustic=applyEscape(acoustic,g,lx,ly,valid);updateWave(g,baseMoved);spatial=waveDisplace(spatial,g,lx,ly,valid,0);acoustic=waveDisplace(acoustic,g,lx,ly,valid,1);var sm=updateSnakeMix(g),spatialStep=.002+snakeSpacing[g]*.0005,soundStep=.002+snakeSpacingSound[g]*.0005,spatialTrail=local<=1?[x,y]:trailPoint(g,(local-1)*spatialStep),soundTrail=local<=1?[x,y]:trailPoint(g,(local-1)*soundStep);spatial=applySnake(spatial,spatialTrail,sm);acoustic=applySnake(acoustic,soundTrail,sm);spatial=applyPortal(spatial,x,y,0);acoustic=applyPortal(acoustic,x,y,1);return[spatial,acoustic];}
function process(x,y){if(!isFinite(x)||!isFinite(y))return;var targets=compute(x,y,swarmCount),spatial=targets[0],acoustic=targets[1],t=clamp((now()-transitionStart)/transitionMs,0,1);if(t<1){spatial=[transitionX+(spatial[0]-transitionX)*t,transitionY+(spatial[1]-transitionY)*t];acoustic=[transitionSoundX+(acoustic[0]-transitionSoundX)*t,transitionSoundY+(acoustic[1]-transitionSoundY)*t];}lastX=spatial[0];lastY=spatial[1];lastSoundX=acoustic[0];lastSoundY=acoustic[1];outlet(0,lastX,lastY);outlet(1,lastSoundX,lastSoundY);}
