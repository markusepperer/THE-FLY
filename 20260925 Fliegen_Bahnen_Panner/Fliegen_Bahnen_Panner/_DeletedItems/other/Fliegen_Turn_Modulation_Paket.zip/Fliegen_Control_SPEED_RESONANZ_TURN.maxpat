{
    "patcher": {
        "fileversion": 1,
        "appversion": {
            "major": 9,
            "minor": 1,
            "revision": 5,
            "architecture": "x64",
            "modernui": 1
        },
        "classnamespace": "box",
        "rect": [
            50.0,
            50.0,
            1050.0,
            650.0
        ],
        "boxes": [
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "send 4_Resonanzmapping",
                    "linecount": 3,
                    "patching_rect": [
                        631.9800991117954,
                        124.46808421611786,
                        78.02959597110748,
                        49.0
                    ],
                    "numinlets": 1,
                    "id": "obj-6",
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "send 3_Resonanzmapping",
                    "linecount": 3,
                    "patching_rect": [
                        459.2465195953846,
                        124.46808421611786,
                        69.14893567562103,
                        49.0
                    ],
                    "numinlets": 1,
                    "id": "obj-5",
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "send 2_Resonanzmapping",
                    "linecount": 3,
                    "patching_rect": [
                        292.9884283840656,
                        120.2127650976181,
                        73.40425479412079,
                        49.0
                    ],
                    "numinlets": 1,
                    "id": "obj-4",
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "send 1_Resonanzmapping",
                    "linecount": 3,
                    "patching_rect": [
                        119.14476838707924,
                        112.76595664024353,
                        79.78723347187042,
                        49.0
                    ],
                    "numinlets": 1,
                    "id": "obj-3",
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "comment",
                    "text": "Koordinaten kommen aus der FLugnahn Abstr. die Speed abstraktion leitet aus den Positions\u00e4nderungen die Geshwindigkeit ab",
                    "linecount": 6,
                    "patching_rect": [
                        792.5531858205795,
                        37.234042286872864,
                        150.0,
                        87.0
                    ],
                    "numinlets": 1,
                    "id": "obj-2",
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "rampsmooth~ 2400 3840",
                    "patching_rect": [
                        617.3912935256958,
                        336.95651721954346,
                        142.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 3,
                    "id": "obj-153",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "rampsmooth~ 2400 3840",
                    "patching_rect": [
                        440.21738386154175,
                        336.95651721954346,
                        142.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 3,
                    "id": "obj-152",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "rampsmooth~ 2400 3840",
                    "patching_rect": [
                        276.08695220947266,
                        336.95651721954346,
                        142.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 3,
                    "id": "obj-151",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "rampsmooth~ 2400 3840",
                    "patching_rect": [
                        105.43478155136108,
                        336.95651721954346,
                        142.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 3,
                    "id": "obj-150",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "sig~",
                    "patching_rect": [
                        617.3912935256958,
                        297.8260831832886,
                        31.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 1,
                    "id": "obj-149",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "sig~",
                    "patching_rect": [
                        440.21738386154175,
                        302.1739091873169,
                        31.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 1,
                    "id": "obj-148",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "sig~",
                    "patching_rect": [
                        276.08695220947266,
                        307.6086916923523,
                        31.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 1,
                    "id": "obj-147",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "sig~",
                    "patching_rect": [
                        105.43478155136108,
                        302.1739091873169,
                        31.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 1,
                    "id": "obj-146",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        617.3912935256958,
                        270.6521706581116,
                        66.30434656143188,
                        22.0
                    ],
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "format": 6,
                    "numinlets": 1,
                    "parameter_enable": 0,
                    "id": "obj-145",
                    "numoutlets": 2
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        440.21738386154175,
                        274.9999966621399,
                        66.30434656143188,
                        22.0
                    ],
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "format": 6,
                    "numinlets": 1,
                    "parameter_enable": 0,
                    "id": "obj-144",
                    "numoutlets": 2
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        276.08695220947266,
                        274.9999966621399,
                        66.30434656143188,
                        22.0
                    ],
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "format": 6,
                    "numinlets": 1,
                    "parameter_enable": 0,
                    "id": "obj-143",
                    "numoutlets": 2
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        105.43478155136108,
                        274.9999966621399,
                        66.30434656143188,
                        22.0
                    ],
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "format": 6,
                    "numinlets": 1,
                    "parameter_enable": 0,
                    "id": "obj-142",
                    "numoutlets": 2
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "scale 0.0005 0.015 0.5 1.",
                    "patching_rect": [
                        617.3912935256958,
                        241.3043451309204,
                        143.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 6,
                    "id": "obj-140",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "scale 0.0005 0.015 0.5 1.",
                    "patching_rect": [
                        440.21738386154175,
                        247.8260841369629,
                        143.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 6,
                    "id": "obj-139",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "scale 0.0005 0.015 0.5 1.",
                    "patching_rect": [
                        276.08695220947266,
                        247.8260841369629,
                        143.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 6,
                    "id": "obj-138",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "scale 0.0005 0.015 0.5 1.",
                    "patching_rect": [
                        105.43478155136108,
                        247.8260841369629,
                        143.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 6,
                    "id": "obj-137",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "clip 0.0005 0.015",
                    "patching_rect": [
                        617.3912935256958,
                        213.04347610473633,
                        100.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 3,
                    "id": "obj-136",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "clip 0.0005 0.015",
                    "patching_rect": [
                        440.21738386154175,
                        215.2173891067505,
                        100.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 3,
                    "id": "obj-135",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "clip 0.0005 0.015",
                    "patching_rect": [
                        276.08695220947266,
                        215.2173891067505,
                        100.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 3,
                    "id": "obj-134",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "clip 0.0005 0.015",
                    "patching_rect": [
                        105.43478155136108,
                        213.04347610473633,
                        100.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 3,
                    "id": "obj-131",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        105.43478155136108,
                        182.6086940765381,
                        107.20720714330673,
                        22.0
                    ],
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "format": 6,
                    "numinlets": 1,
                    "parameter_enable": 0,
                    "id": "obj-129",
                    "numoutlets": 2
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "MS_XY_Speed",
                    "patching_rect": [
                        105.31914818286896,
                        77.65957391262054,
                        91.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 1,
                    "id": "obj-130",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        276.08695220947266,
                        182.6086940765381,
                        107.20720714330673,
                        22.0
                    ],
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "format": 6,
                    "numinlets": 1,
                    "parameter_enable": 0,
                    "id": "obj-127",
                    "numoutlets": 2
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "MS_XY_Speed",
                    "patching_rect": [
                        275.5319129228592,
                        77.65957391262054,
                        91.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 1,
                    "id": "obj-128",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        440.21738386154175,
                        186.9565200805664,
                        107.20720714330673,
                        22.0
                    ],
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "format": 6,
                    "numinlets": 1,
                    "parameter_enable": 0,
                    "id": "obj-123",
                    "numoutlets": 2
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "MS_XY_Speed",
                    "patching_rect": [
                        440.42552876472473,
                        82.97872281074524,
                        91.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 1,
                    "id": "obj-124",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        617.3912935256958,
                        182.6086940765381,
                        107.20720714330673,
                        22.0
                    ],
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "format": 6,
                    "numinlets": 1,
                    "parameter_enable": 0,
                    "id": "obj-118",
                    "numoutlets": 2
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "MS_XY_Speed",
                    "patching_rect": [
                        617.0212721824646,
                        77.65957391262054,
                        91.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 1,
                    "id": "obj-116",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "message",
                    "text": "0.912607 0.473664",
                    "linecount": 4,
                    "patching_rect": [
                        385.1063802242279,
                        82.97872281074524,
                        50.0,
                        62.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 2,
                    "id": "obj-115",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "message",
                    "text": "0.502271 0.407612",
                    "linecount": 4,
                    "patching_rect": [
                        222.34042394161224,
                        76.5957441329956,
                        50.0,
                        62.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 2,
                    "id": "obj-114",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "message",
                    "text": "0.312829 0.575257",
                    "linecount": 4,
                    "patching_rect": [
                        49.99999964237213,
                        76.5957441329956,
                        50.0,
                        62.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 2,
                    "id": "obj-113",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "message",
                    "text": "0.828486 0.393979",
                    "linecount": 4,
                    "patching_rect": [
                        558.510634303093,
                        82.97872281074524,
                        50.0,
                        62.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 2,
                    "id": "obj-112",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "receive 3_Flugkoordinaten",
                    "patching_rect": [
                        415.95744383335114,
                        34.04255294799805,
                        150.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 0,
                    "id": "obj-109",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "receive 2_Flugkoordinaten",
                    "patching_rect": [
                        252.12765777111053,
                        34.04255294799805,
                        150.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 0,
                    "id": "obj-110",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "receive 1_Flugkoordinaten",
                    "patching_rect": [
                        89.36170148849487,
                        34.04255294799805,
                        150.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 0,
                    "id": "obj-108",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "receive 4_Flugkoordinaten",
                    "patching_rect": [
                        589.3616979122162,
                        34.04255294799805,
                        150.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 0,
                    "id": "obj-107",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "outlet",
                    "patching_rect": [
                        105.43480625677489,
                        418.9565208635559,
                        30.0,
                        30.0
                    ],
                    "numinlets": 1,
                    "id": "obj-158",
                    "numoutlets": 0,
                    "comment": "",
                    "index": 1
                }
            },
            {
                "box": {
                    "maxclass": "outlet",
                    "patching_rect": [
                        276.086966256775,
                        418.9565208635559,
                        30.0,
                        30.0
                    ],
                    "numinlets": 1,
                    "id": "obj-159",
                    "numoutlets": 0,
                    "comment": "",
                    "index": 2
                }
            },
            {
                "box": {
                    "maxclass": "outlet",
                    "patching_rect": [
                        440.21733725677495,
                        418.9565208635559,
                        30.0,
                        30.0
                    ],
                    "numinlets": 1,
                    "id": "obj-160",
                    "numoutlets": 0,
                    "comment": "",
                    "index": 3
                }
            },
            {
                "box": {
                    "maxclass": "outlet",
                    "patching_rect": [
                        617.3912882567749,
                        418.9565208635559,
                        30.0,
                        30.0
                    ],
                    "numinlets": 1,
                    "id": "obj-161",
                    "numoutlets": 0,
                    "comment": "",
                    "index": 4
                }
            },
            {
                "box": {
                    "maxclass": "comment",
                    "patching_rect": [
                        790.0,
                        145.0,
                        230.0,
                        34.0
                    ],
                    "id": "turn-title",
                    "text": "NEU: Richtungs\u00e4nderung aus denselben XY-Daten",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "linecount": 2
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        105.0,
                        470.0,
                        88.0,
                        22.0
                    ],
                    "id": "turn-1",
                    "text": "MS_XY_Turn",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        105.0,
                        500.0,
                        72.0,
                        22.0
                    ],
                    "id": "turnnum-1",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "format": 6
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        105.0,
                        535.0,
                        125.0,
                        22.0
                    ],
                    "id": "turnsend-1",
                    "text": "send 1_Turnmapping",
                    "numinlets": 1,
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        275.0,
                        470.0,
                        88.0,
                        22.0
                    ],
                    "id": "turn-2",
                    "text": "MS_XY_Turn",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        275.0,
                        500.0,
                        72.0,
                        22.0
                    ],
                    "id": "turnnum-2",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "format": 6
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        275.0,
                        535.0,
                        125.0,
                        22.0
                    ],
                    "id": "turnsend-2",
                    "text": "send 2_Turnmapping",
                    "numinlets": 1,
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        440.0,
                        470.0,
                        88.0,
                        22.0
                    ],
                    "id": "turn-3",
                    "text": "MS_XY_Turn",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        440.0,
                        500.0,
                        72.0,
                        22.0
                    ],
                    "id": "turnnum-3",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "format": 6
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        440.0,
                        535.0,
                        125.0,
                        22.0
                    ],
                    "id": "turnsend-3",
                    "text": "send 3_Turnmapping",
                    "numinlets": 1,
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        617.0,
                        470.0,
                        88.0,
                        22.0
                    ],
                    "id": "turn-4",
                    "text": "MS_XY_Turn",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        617.0,
                        500.0,
                        72.0,
                        22.0
                    ],
                    "id": "turnnum-4",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "format": 6
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        617.0,
                        535.0,
                        125.0,
                        22.0
                    ],
                    "id": "turnsend-4",
                    "text": "send 4_Turnmapping",
                    "numinlets": 1,
                    "numoutlets": 0
                }
            }
        ],
        "lines": [
            {
                "patchline": {
                    "source": [
                        "obj-116",
                        0
                    ],
                    "destination": [
                        "obj-6",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-124",
                        0
                    ],
                    "destination": [
                        "obj-5",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-128",
                        0
                    ],
                    "destination": [
                        "obj-4",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-130",
                        0
                    ],
                    "destination": [
                        "obj-3",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-107",
                        0
                    ],
                    "destination": [
                        "obj-112",
                        1
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-107",
                        0
                    ],
                    "destination": [
                        "obj-116",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-109",
                        0
                    ],
                    "destination": [
                        "obj-115",
                        1
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-109",
                        0
                    ],
                    "destination": [
                        "obj-124",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-110",
                        0
                    ],
                    "destination": [
                        "obj-114",
                        1
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-110",
                        0
                    ],
                    "destination": [
                        "obj-128",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-108",
                        0
                    ],
                    "destination": [
                        "obj-130",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-108",
                        0
                    ],
                    "destination": [
                        "obj-113",
                        1
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-116",
                        0
                    ],
                    "destination": [
                        "obj-118",
                        0
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-124",
                        0
                    ],
                    "destination": [
                        "obj-123",
                        0
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-128",
                        0
                    ],
                    "destination": [
                        "obj-127",
                        0
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-130",
                        0
                    ],
                    "destination": [
                        "obj-129",
                        0
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-129",
                        0
                    ],
                    "destination": [
                        "obj-131",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-127",
                        0
                    ],
                    "destination": [
                        "obj-134",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-118",
                        0
                    ],
                    "destination": [
                        "obj-136",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-131",
                        0
                    ],
                    "destination": [
                        "obj-137",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-134",
                        0
                    ],
                    "destination": [
                        "obj-138",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-135",
                        0
                    ],
                    "destination": [
                        "obj-139",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-123",
                        0
                    ],
                    "destination": [
                        "obj-135",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-136",
                        0
                    ],
                    "destination": [
                        "obj-140",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-137",
                        0
                    ],
                    "destination": [
                        "obj-142",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-138",
                        0
                    ],
                    "destination": [
                        "obj-143",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-139",
                        0
                    ],
                    "destination": [
                        "obj-144",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-140",
                        0
                    ],
                    "destination": [
                        "obj-145",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-142",
                        0
                    ],
                    "destination": [
                        "obj-146",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-143",
                        0
                    ],
                    "destination": [
                        "obj-147",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-144",
                        0
                    ],
                    "destination": [
                        "obj-148",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-145",
                        0
                    ],
                    "destination": [
                        "obj-149",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-146",
                        0
                    ],
                    "destination": [
                        "obj-150",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-147",
                        0
                    ],
                    "destination": [
                        "obj-151",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-148",
                        0
                    ],
                    "destination": [
                        "obj-152",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-149",
                        0
                    ],
                    "destination": [
                        "obj-153",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-150",
                        0
                    ],
                    "destination": [
                        "obj-158",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-151",
                        0
                    ],
                    "destination": [
                        "obj-159",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-152",
                        0
                    ],
                    "destination": [
                        "obj-160",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-153",
                        0
                    ],
                    "destination": [
                        "obj-161",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-108",
                        0
                    ],
                    "destination": [
                        "turn-1",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-1",
                        0
                    ],
                    "destination": [
                        "turnnum-1",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turnnum-1",
                        0
                    ],
                    "destination": [
                        "turnsend-1",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-110",
                        0
                    ],
                    "destination": [
                        "turn-2",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-2",
                        0
                    ],
                    "destination": [
                        "turnnum-2",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turnnum-2",
                        0
                    ],
                    "destination": [
                        "turnsend-2",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-109",
                        0
                    ],
                    "destination": [
                        "turn-3",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-3",
                        0
                    ],
                    "destination": [
                        "turnnum-3",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turnnum-3",
                        0
                    ],
                    "destination": [
                        "turnsend-3",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-107",
                        0
                    ],
                    "destination": [
                        "turn-4",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-4",
                        0
                    ],
                    "destination": [
                        "turnnum-4",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turnnum-4",
                        0
                    ],
                    "destination": [
                        "turnsend-4",
                        0
                    ]
                }
            }
        ]
    }
}