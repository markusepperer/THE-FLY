{
    "patcher": {
        "fileversion": 1,
        "appversion": {
            "major": 9,
            "minor": 1,
            "revision": 5,
            "architecture": "x64",
            "modernui": 1
        },
        "classnamespace": "box",
        "rect": [
            100.0,
            100.0,
            760.0,
            880.0
        ],
        "description": "Direction-change metric from XY trajectories",
        "boxes": [
            {
                "box": {
                    "maxclass": "comment",
                    "patching_rect": [
                        35.0,
                        18.0,
                        560.0,
                        21.0
                    ],
                    "id": "title",
                    "text": "MS_XY_Turn \u2014 Richtungs\u00e4nderung aus aufeinanderfolgenden XY-Bewegungsvektoren",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "fontsize": 13.0
                }
            },
            {
                "box": {
                    "maxclass": "comment",
                    "patching_rect": [
                        35.0,
                        42.0,
                        650.0,
                        34.0
                    ],
                    "id": "sub",
                    "text": "Outlet 1: Betrag 0..1 (0 = gerade, 1 = 180\u00b0). Outlet 2: vorzeichenbehaftet -1..1. Bewegungen < 0.0005 werden ignoriert.",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "linecount": 2
                }
            },
            {
                "box": {
                    "maxclass": "inlet",
                    "patching_rect": [
                        45.0,
                        95.0,
                        30.0,
                        30.0
                    ],
                    "id": "in",
                    "numinlets": 0,
                    "numoutlets": 1,
                    "index": 1,
                    "comment": "XY-Liste: x y"
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        45.0,
                        140.0,
                        45.0,
                        22.0
                    ],
                    "id": "trig",
                    "text": "t l",
                    "numinlets": 1,
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        110.0,
                        140.0,
                        88.0,
                        22.0
                    ],
                    "id": "unpack",
                    "text": "unpack 0. 0.",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "float",
                        "float"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        85.0,
                        190.0,
                        42.0,
                        22.0
                    ],
                    "id": "tx",
                    "text": "t f f",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "float",
                        "float"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        145.0,
                        190.0,
                        58.0,
                        22.0
                    ],
                    "id": "bx",
                    "text": "bucket 1",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        85.0,
                        235.0,
                        48.0,
                        22.0
                    ],
                    "id": "subx",
                    "text": "- 0.",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        "float"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        280.0,
                        190.0,
                        42.0,
                        22.0
                    ],
                    "id": "ty",
                    "text": "t f f",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "float",
                        "float"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        340.0,
                        190.0,
                        58.0,
                        22.0
                    ],
                    "id": "by",
                    "text": "bucket 1",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        280.0,
                        235.0,
                        48.0,
                        22.0
                    ],
                    "id": "suby",
                    "text": "- 0.",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        "float"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        85.0,
                        280.0,
                        42.0,
                        22.0
                    ],
                    "id": "tdx",
                    "text": "t f f",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "float",
                        "float"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        145.0,
                        280.0,
                        58.0,
                        22.0
                    ],
                    "id": "bdx",
                    "text": "bucket 1",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        280.0,
                        280.0,
                        42.0,
                        22.0
                    ],
                    "id": "tdy",
                    "text": "t f f",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "float",
                        "float"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        340.0,
                        280.0,
                        58.0,
                        22.0
                    ],
                    "id": "bdy",
                    "text": "bucket 1",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        175.0,
                        330.0,
                        72.0,
                        22.0
                    ],
                    "id": "buddy4",
                    "text": "buddy 4",
                    "numinlets": 4,
                    "numoutlets": 4,
                    "outlettype": [
                        "",
                        "",
                        "",
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        175.0,
                        370.0,
                        116.0,
                        22.0
                    ],
                    "id": "pack4",
                    "text": "pack 0. 0. 0. 0.",
                    "numinlets": 4,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        175.0,
                        410.0,
                        55.0,
                        22.0
                    ],
                    "id": "tlists",
                    "text": "t l l l",
                    "numinlets": 1,
                    "numoutlets": 3,
                    "outlettype": [
                        "",
                        "",
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        420.0,
                        445.0,
                        215.0,
                        22.0
                    ],
                    "id": "magprev",
                    "text": "expr sqrt($f3*$f3+$f4*$f4) > 0.0005",
                    "numinlets": 4,
                    "numoutlets": 1,
                    "outlettype": [
                        "int"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        420.0,
                        480.0,
                        215.0,
                        22.0
                    ],
                    "id": "magcur",
                    "text": "expr sqrt($f1*$f1+$f2*$f2) > 0.0005",
                    "numinlets": 4,
                    "numoutlets": 1,
                    "outlettype": [
                        "int"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        420.0,
                        520.0,
                        58.0,
                        22.0
                    ],
                    "id": "buddyvalid",
                    "text": "buddy 2",
                    "numinlets": 2,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        420.0,
                        555.0,
                        62.0,
                        22.0
                    ],
                    "id": "packvalid",
                    "text": "pack 0 0",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        420.0,
                        590.0,
                        82.0,
                        22.0
                    ],
                    "id": "andexpr",
                    "text": "expr $i1*$i2",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        "int"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        175.0,
                        445.0,
                        355.0,
                        22.0
                    ],
                    "id": "angle",
                    "text": "expr atan2($f3*$f2-$f4*$f1\\, $f3*$f1+$f4*$f2)/3.141592653589793",
                    "numinlets": 4,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        175.0,
                        625.0,
                        42.0,
                        22.0
                    ],
                    "id": "gate",
                    "text": "gate 1",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        175.0,
                        665.0,
                        42.0,
                        22.0
                    ],
                    "id": "tf",
                    "text": "t f f",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "float",
                        "float"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        280.0,
                        665.0,
                        85.0,
                        22.0
                    ],
                    "id": "abs",
                    "text": "expr abs($f1)",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        110.0,
                        705.0,
                        72.0,
                        22.0
                    ],
                    "id": "signednum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "format": 6
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        280.0,
                        705.0,
                        72.0,
                        22.0
                    ],
                    "id": "amountnum",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "format": 6
                }
            },
            {
                "box": {
                    "maxclass": "outlet",
                    "patching_rect": [
                        280.0,
                        755.0,
                        30.0,
                        30.0
                    ],
                    "id": "outamount",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "index": 1,
                    "comment": "Turn amount 0..1"
                }
            },
            {
                "box": {
                    "maxclass": "outlet",
                    "patching_rect": [
                        110.0,
                        755.0,
                        30.0,
                        30.0
                    ],
                    "id": "outsigned",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "index": 2,
                    "comment": "Signed turn -1..1"
                }
            },
            {
                "box": {
                    "maxclass": "comment",
                    "patching_rect": [
                        35.0,
                        805.0,
                        680.0,
                        50.0
                    ],
                    "id": "note",
                    "text": "Berechnung: atan2(cross(prev,current), dot(prev,current)) / pi. Das liefert den kleinsten vorzeichenbehafteten Winkel zwischen zwei Bewegungsvektoren. Der Betrag ist die Wendungsst\u00e4rke.",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "linecount": 3
                }
            }
        ],
        "lines": [
            {
                "patchline": {
                    "source": [
                        "in",
                        0
                    ],
                    "destination": [
                        "trig",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "trig",
                        0
                    ],
                    "destination": [
                        "unpack",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "unpack",
                        0
                    ],
                    "destination": [
                        "tx",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "unpack",
                        1
                    ],
                    "destination": [
                        "ty",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tx",
                        1
                    ],
                    "destination": [
                        "bx",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "bx",
                        0
                    ],
                    "destination": [
                        "subx",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tx",
                        0
                    ],
                    "destination": [
                        "subx",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "ty",
                        1
                    ],
                    "destination": [
                        "by",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "by",
                        0
                    ],
                    "destination": [
                        "suby",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "ty",
                        0
                    ],
                    "destination": [
                        "suby",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "subx",
                        0
                    ],
                    "destination": [
                        "tdx",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tdx",
                        1
                    ],
                    "destination": [
                        "bdx",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tdx",
                        0
                    ],
                    "destination": [
                        "buddy4",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "bdx",
                        0
                    ],
                    "destination": [
                        "buddy4",
                        2
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "suby",
                        0
                    ],
                    "destination": [
                        "tdy",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tdy",
                        1
                    ],
                    "destination": [
                        "bdy",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tdy",
                        0
                    ],
                    "destination": [
                        "buddy4",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "bdy",
                        0
                    ],
                    "destination": [
                        "buddy4",
                        3
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "buddy4",
                        3
                    ],
                    "destination": [
                        "pack4",
                        3
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "buddy4",
                        2
                    ],
                    "destination": [
                        "pack4",
                        2
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "buddy4",
                        1
                    ],
                    "destination": [
                        "pack4",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "buddy4",
                        0
                    ],
                    "destination": [
                        "pack4",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "pack4",
                        0
                    ],
                    "destination": [
                        "tlists",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tlists",
                        2
                    ],
                    "destination": [
                        "magprev",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tlists",
                        1
                    ],
                    "destination": [
                        "magcur",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "magprev",
                        0
                    ],
                    "destination": [
                        "buddyvalid",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "magcur",
                        0
                    ],
                    "destination": [
                        "buddyvalid",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "buddyvalid",
                        1
                    ],
                    "destination": [
                        "packvalid",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "buddyvalid",
                        0
                    ],
                    "destination": [
                        "packvalid",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "packvalid",
                        0
                    ],
                    "destination": [
                        "andexpr",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "andexpr",
                        0
                    ],
                    "destination": [
                        "gate",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tlists",
                        0
                    ],
                    "destination": [
                        "angle",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "angle",
                        0
                    ],
                    "destination": [
                        "gate",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "gate",
                        0
                    ],
                    "destination": [
                        "tf",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tf",
                        1
                    ],
                    "destination": [
                        "signednum",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "signednum",
                        0
                    ],
                    "destination": [
                        "outsigned",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "tf",
                        0
                    ],
                    "destination": [
                        "abs",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "abs",
                        0
                    ],
                    "destination": [
                        "amountnum",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "amountnum",
                        0
                    ],
                    "destination": [
                        "outamount",
                        0
                    ]
                }
            }
        ]
    }
}