{
    "patcher": {
        "fileversion": 1,
        "appversion": {
            "major": 9,
            "minor": 1,
            "revision": 5,
            "architecture": "x64",
            "modernui": 1
        },
        "classnamespace": "box",
        "rect": [
            50.0,
            50.0,
            1100.0,
            720.0
        ],
        "boxes": [
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "+~",
                    "patching_rect": [
                        309.0,
                        378.0,
                        29.5,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "obj-17",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "rampsmooth~ 2400 3840",
                    "patching_rect": [
                        504.71700459718704,
                        247.16982281208038,
                        142.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 3,
                    "id": "obj-14",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "sig~",
                    "patching_rect": [
                        504.71700459718704,
                        217.9245384335518,
                        31.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 1,
                    "id": "obj-13",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "scale 0.0005 0.015 0. 0.3",
                    "patching_rect": [
                        504.71700459718704,
                        187.73585778474808,
                        143.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 6,
                    "id": "obj-11",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "clip 0.0005 0.015",
                    "patching_rect": [
                        504.71700459718704,
                        156.60378086566925,
                        100.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 3,
                    "id": "obj-10",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "receive #1_Resonanzmapping",
                    "patching_rect": [
                        504.71700459718704,
                        124.52830767631531,
                        171.0,
                        22.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 0,
                    "id": "obj-6",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "inlet",
                    "patching_rect": [
                        178.0,
                        52.0,
                        30.0,
                        30.0
                    ],
                    "outlettype": [
                        ""
                    ],
                    "numinlets": 0,
                    "id": "obj-3",
                    "numoutlets": 1,
                    "comment": "",
                    "index": 1
                }
            },
            {
                "box": {
                    "maxclass": "number",
                    "patching_rect": [
                        178.0,
                        217.0,
                        50.0,
                        22.0
                    ],
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "numinlets": 1,
                    "parameter_enable": 0,
                    "id": "obj-2",
                    "numoutlets": 2
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "noise~",
                    "patching_rect": [
                        50.0,
                        100.0,
                        54.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 1,
                    "id": "noise-freq",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "onepole~ 4",
                    "patching_rect": [
                        50.0,
                        138.46154034137726,
                        84.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "lp4a",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "onepole~ 4",
                    "patching_rect": [
                        50.0,
                        174.72527837753296,
                        84.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "lp4b",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "*~ 700",
                    "patching_rect": [
                        50.0,
                        210.98901641368866,
                        58.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "freq-depth",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "+~ 220",
                    "patching_rect": [
                        50.0,
                        247.25275444984436,
                        60.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "freq-base",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "noise~",
                    "patching_rect": [
                        340.1099042892456,
                        100.0,
                        54.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 1,
                    "id": "noise-res",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "onepole~ 5",
                    "patching_rect": [
                        340.1099042892456,
                        138.46154034137726,
                        84.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "lp5a",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "onepole~ 5",
                    "patching_rect": [
                        340.1099042892456,
                        174.72527837753296,
                        84.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "lp5b",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "*~ 40",
                    "patching_rect": [
                        299.4505616426468,
                        217.58242332935333,
                        52.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "res-depth",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "+~ 5",
                    "patching_rect": [
                        299.4505616426468,
                        253.84616136550903,
                        46.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "res-base",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "*~ 3",
                    "patching_rect": [
                        434.6154034137726,
                        217.58242332935333,
                        46.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "offset-depth",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "+~",
                    "patching_rect": [
                        434.6154034137726,
                        253.84616136550903,
                        40.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "freq2-sum",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "p flywing_L",
                    "patching_rect": [
                        165.5462086200714,
                        430.2520751953125,
                        88.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "wing1",
                    "numoutlets": 1,
                    "patcher": {
                        "fileversion": 1,
                        "appversion": {
                            "major": 9,
                            "minor": 1,
                            "revision": 5,
                            "architecture": "x64",
                            "modernui": 1
                        },
                        "classnamespace": "box",
                        "rect": [
                            59.0,
                            104.0,
                            600.0,
                            930.0
                        ],
                        "description": "Farnell housefly wing",
                        "digest": "Max translation of Designing Sound Fig. 50.13",
                        "tags": "fly insect Farnell",
                        "boxes": [
                            {
                                "box": {
                                    "maxclass": "comment",
                                    "text": "Farnell fly wing \u2014 Max translation of Designing Sound Fig. 50.13",
                                    "patching_rect": [
                                        30.0,
                                        12.0,
                                        430.0,
                                        21.0
                                    ],
                                    "numinlets": 1,
                                    "id": "fw-title",
                                    "numoutlets": 0,
                                    "fontsize": 13.0
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "inlet",
                                    "patching_rect": [
                                        55.0,
                                        55.0,
                                        30.0,
                                        30.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 0,
                                    "id": "fw-res-in",
                                    "numoutlets": 1,
                                    "comment": "wing resonance 0..100",
                                    "index": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "inlet",
                                    "patching_rect": [
                                        325.0,
                                        55.0,
                                        30.0,
                                        30.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 0,
                                    "id": "fw-freq-in",
                                    "numoutlets": 1,
                                    "comment": "wing frequency Hz",
                                    "index": 2
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "/~ 100.",
                                    "patching_rect": [
                                        55.0,
                                        110.0,
                                        54.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-div100",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "phasor~ 756",
                                    "patching_rect": [
                                        325.0,
                                        110.0,
                                        76.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-phasor",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 0.2",
                                    "patching_rect": [
                                        235.0,
                                        155.0,
                                        52.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-mul02",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ -1",
                                    "patching_rect": [
                                        350.0,
                                        155.0,
                                        48.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-mulneg1",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "+~ 1",
                                    "patching_rect": [
                                        350.0,
                                        190.0,
                                        42.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-add1",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "minimum~",
                                    "patching_rect": [
                                        220.0,
                                        225.0,
                                        76.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-minA",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "minimum~",
                                    "patching_rect": [
                                        340.0,
                                        225.0,
                                        76.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-minB",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "minimum~",
                                    "patching_rect": [
                                        280.0,
                                        265.0,
                                        76.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-minC",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 6",
                                    "patching_rect": [
                                        290.0,
                                        300.0,
                                        46.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-mul6",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "-~ 0.5",
                                    "patching_rect": [
                                        288.0,
                                        335.0,
                                        54.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-sub05",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 2",
                                    "patching_rect": [
                                        292.0,
                                        370.0,
                                        46.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-mul2shape",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "minimum~ 0",
                                    "patching_rect": [
                                        190.0,
                                        415.0,
                                        86.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-down",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "maximum~ 0",
                                    "patching_rect": [
                                        330.0,
                                        415.0,
                                        90.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-up",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~",
                                    "patching_rect": [
                                        160.0,
                                        465.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-resmul",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "pong~ 1 0 1",
                                    "patching_rect": [
                                        160.0,
                                        500.0,
                                        82.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 3,
                                    "id": "fw-wrap",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "cos~",
                                    "patching_rect": [
                                        160.0,
                                        535.0,
                                        42.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 1,
                                    "id": "fw-cos",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 0.5",
                                    "patching_rect": [
                                        160.0,
                                        570.0,
                                        52.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-ovscale",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "+~",
                                    "patching_rect": [
                                        205.0,
                                        610.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-downsum",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~",
                                    "patching_rect": [
                                        345.0,
                                        465.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-upsquare",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~",
                                    "patching_rect": [
                                        345.0,
                                        500.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-upquartic",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 2",
                                    "patching_rect": [
                                        345.0,
                                        535.0,
                                        46.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-upscale",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "+~",
                                    "patching_rect": [
                                        275.0,
                                        655.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-sum",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "onepole~ 700",
                                    "patching_rect": [
                                        300.0,
                                        700.0,
                                        90.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-onepole",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "-~",
                                    "patching_rect": [
                                        255.0,
                                        740.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-highpass-sub",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 0.5",
                                    "patching_rect": [
                                        255.0,
                                        775.0,
                                        52.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-outscale",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "outlet",
                                    "patching_rect": [
                                        260.0,
                                        825.0,
                                        30.0,
                                        30.0
                                    ],
                                    "numinlets": 1,
                                    "id": "fw-out",
                                    "numoutlets": 0,
                                    "comment": "mono fly-wing signal",
                                    "index": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "comment",
                                    "text": "High-pass stage follows the established Max translation: original signal minus onepole~ 700 low-pass.",
                                    "linecount": 2,
                                    "patching_rect": [
                                        30.0,
                                        865.0,
                                        520.0,
                                        33.0
                                    ],
                                    "numinlets": 1,
                                    "id": "fw-note",
                                    "numoutlets": 0
                                }
                            }
                        ],
                        "lines": [
                            {
                                "patchline": {
                                    "source": [
                                        "fw-wrap",
                                        0
                                    ],
                                    "destination": [
                                        "fw-cos",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-upsquare",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upquartic",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-upsquare",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upquartic",
                                        1
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-upscale",
                                        0
                                    ],
                                    "destination": [
                                        "fw-sum",
                                        1
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-upquartic",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upscale",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-up",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upsquare",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-up",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upsquare",
                                        1
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-sum",
                                        0
                                    ],
                                    "destination": [
                                        "fw-onepole",
                                        0
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-sum",
                                        0
                                    ],
                                    "destination": [
                                        "fw-highpass-sub",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-sub05",
                                        0
                                    ],
                                    "destination": [
                                        "fw-mul2shape",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-resmul",
                                        0
                                    ],
                                    "destination": [
                                        "fw-wrap",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-res-in",
                                        0
                                    ],
                                    "destination": [
                                        "fw-div100",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-phasor",
                                        0
                                    ],
                                    "destination": [
                                        "fw-mulneg1",
                                        0
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-phasor",
                                        0
                                    ],
                                    "destination": [
                                        "fw-mul02",
                                        0
                                    ],
                                    "order": 2
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-phasor",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minB",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-ovscale",
                                        0
                                    ],
                                    "destination": [
                                        "fw-downsum",
                                        1
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-outscale",
                                        0
                                    ],
                                    "destination": [
                                        "fw-out",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-onepole",
                                        0
                                    ],
                                    "destination": [
                                        "fw-highpass-sub",
                                        1
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mulneg1",
                                        0
                                    ],
                                    "destination": [
                                        "fw-add1",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mul6",
                                        0
                                    ],
                                    "destination": [
                                        "fw-sub05",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mul2shape",
                                        0
                                    ],
                                    "destination": [
                                        "fw-up",
                                        0
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mul2shape",
                                        0
                                    ],
                                    "destination": [
                                        "fw-down",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mul02",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minA",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-minC",
                                        0
                                    ],
                                    "destination": [
                                        "fw-mul6",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-minB",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minC",
                                        1
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-minA",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minC",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-highpass-sub",
                                        0
                                    ],
                                    "destination": [
                                        "fw-outscale",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-freq-in",
                                        0
                                    ],
                                    "destination": [
                                        "fw-phasor",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-downsum",
                                        0
                                    ],
                                    "destination": [
                                        "fw-sum",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-down",
                                        0
                                    ],
                                    "destination": [
                                        "fw-resmul",
                                        1
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-down",
                                        0
                                    ],
                                    "destination": [
                                        "fw-downsum",
                                        0
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-div100",
                                        0
                                    ],
                                    "destination": [
                                        "fw-resmul",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-cos",
                                        0
                                    ],
                                    "destination": [
                                        "fw-ovscale",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-add1",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minB",
                                        1
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-add1",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minA",
                                        1
                                    ],
                                    "order": 1
                                }
                            }
                        ]
                    },
                    "saved_object_attributes": {
                        "description": "Farnell housefly wing",
                        "digest": "Max translation of Designing Sound Fig. 50.13",
                        "tags": "fly insect Farnell"
                    }
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "p flywing_R",
                    "patching_rect": [
                        414.28568959236145,
                        430.2520751953125,
                        88.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "wing2",
                    "numoutlets": 1,
                    "patcher": {
                        "fileversion": 1,
                        "appversion": {
                            "major": 9,
                            "minor": 1,
                            "revision": 5,
                            "architecture": "x64",
                            "modernui": 1
                        },
                        "classnamespace": "box",
                        "rect": [
                            59.0,
                            107.0,
                            600.0,
                            930.0
                        ],
                        "description": "Farnell housefly wing",
                        "digest": "Max translation of Designing Sound Fig. 50.13",
                        "tags": "fly insect Farnell",
                        "boxes": [
                            {
                                "box": {
                                    "maxclass": "comment",
                                    "text": "Farnell fly wing \u2014 Max translation of Designing Sound Fig. 50.13",
                                    "patching_rect": [
                                        30.0,
                                        12.0,
                                        430.0,
                                        21.0
                                    ],
                                    "numinlets": 1,
                                    "id": "fw-title",
                                    "numoutlets": 0,
                                    "fontsize": 13.0
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "inlet",
                                    "patching_rect": [
                                        55.0,
                                        55.0,
                                        30.0,
                                        30.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 0,
                                    "id": "fw-res-in",
                                    "numoutlets": 1,
                                    "comment": "wing resonance 0..100",
                                    "index": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "inlet",
                                    "patching_rect": [
                                        325.0,
                                        55.0,
                                        30.0,
                                        30.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 0,
                                    "id": "fw-freq-in",
                                    "numoutlets": 1,
                                    "comment": "wing frequency Hz",
                                    "index": 2
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "/~ 100.",
                                    "patching_rect": [
                                        55.0,
                                        110.0,
                                        54.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-div100",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "phasor~ 756",
                                    "patching_rect": [
                                        325.0,
                                        110.0,
                                        76.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-phasor",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 0.2",
                                    "patching_rect": [
                                        235.0,
                                        155.0,
                                        52.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-mul02",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ -1",
                                    "patching_rect": [
                                        350.0,
                                        155.0,
                                        48.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-mulneg1",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "+~ 1",
                                    "patching_rect": [
                                        350.0,
                                        190.0,
                                        42.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-add1",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "minimum~",
                                    "patching_rect": [
                                        220.0,
                                        225.0,
                                        76.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-minA",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "minimum~",
                                    "patching_rect": [
                                        340.0,
                                        225.0,
                                        76.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-minB",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "minimum~",
                                    "patching_rect": [
                                        280.0,
                                        265.0,
                                        76.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-minC",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 6",
                                    "patching_rect": [
                                        290.0,
                                        300.0,
                                        46.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-mul6",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "-~ 0.5",
                                    "patching_rect": [
                                        288.0,
                                        335.0,
                                        54.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-sub05",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 2",
                                    "patching_rect": [
                                        292.0,
                                        370.0,
                                        46.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-mul2shape",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "minimum~ 0",
                                    "patching_rect": [
                                        190.0,
                                        415.0,
                                        86.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-down",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "maximum~ 0",
                                    "patching_rect": [
                                        330.0,
                                        415.0,
                                        90.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-up",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~",
                                    "patching_rect": [
                                        160.0,
                                        465.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-resmul",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "pong~ 1 0 1",
                                    "patching_rect": [
                                        160.0,
                                        500.0,
                                        82.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 3,
                                    "id": "fw-wrap",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "cos~",
                                    "patching_rect": [
                                        160.0,
                                        535.0,
                                        42.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 1,
                                    "id": "fw-cos",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 0.5",
                                    "patching_rect": [
                                        160.0,
                                        570.0,
                                        52.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-ovscale",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "+~",
                                    "patching_rect": [
                                        205.0,
                                        610.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-downsum",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~",
                                    "patching_rect": [
                                        345.0,
                                        465.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-upsquare",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~",
                                    "patching_rect": [
                                        345.0,
                                        500.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-upquartic",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 2",
                                    "patching_rect": [
                                        345.0,
                                        535.0,
                                        46.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-upscale",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "+~",
                                    "patching_rect": [
                                        275.0,
                                        655.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-sum",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "onepole~ 700",
                                    "patching_rect": [
                                        300.0,
                                        700.0,
                                        90.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-onepole",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "-~",
                                    "patching_rect": [
                                        255.0,
                                        740.0,
                                        40.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-highpass-sub",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "newobj",
                                    "text": "*~ 0.5",
                                    "patching_rect": [
                                        255.0,
                                        775.0,
                                        52.0,
                                        22.0
                                    ],
                                    "outlettype": [
                                        "signal"
                                    ],
                                    "numinlets": 2,
                                    "id": "fw-outscale",
                                    "numoutlets": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "outlet",
                                    "patching_rect": [
                                        260.0,
                                        825.0,
                                        30.0,
                                        30.0
                                    ],
                                    "numinlets": 1,
                                    "id": "fw-out",
                                    "numoutlets": 0,
                                    "comment": "mono fly-wing signal",
                                    "index": 1
                                }
                            },
                            {
                                "box": {
                                    "maxclass": "comment",
                                    "text": "High-pass stage follows the established Max translation: original signal minus onepole~ 700 low-pass.",
                                    "linecount": 2,
                                    "patching_rect": [
                                        30.0,
                                        865.0,
                                        520.0,
                                        33.0
                                    ],
                                    "numinlets": 1,
                                    "id": "fw-note",
                                    "numoutlets": 0
                                }
                            }
                        ],
                        "lines": [
                            {
                                "patchline": {
                                    "source": [
                                        "fw-wrap",
                                        0
                                    ],
                                    "destination": [
                                        "fw-cos",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-upsquare",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upquartic",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-upsquare",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upquartic",
                                        1
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-upscale",
                                        0
                                    ],
                                    "destination": [
                                        "fw-sum",
                                        1
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-upquartic",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upscale",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-up",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upsquare",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-up",
                                        0
                                    ],
                                    "destination": [
                                        "fw-upsquare",
                                        1
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-sum",
                                        0
                                    ],
                                    "destination": [
                                        "fw-onepole",
                                        0
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-sum",
                                        0
                                    ],
                                    "destination": [
                                        "fw-highpass-sub",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-sub05",
                                        0
                                    ],
                                    "destination": [
                                        "fw-mul2shape",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-resmul",
                                        0
                                    ],
                                    "destination": [
                                        "fw-wrap",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-res-in",
                                        0
                                    ],
                                    "destination": [
                                        "fw-div100",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-phasor",
                                        0
                                    ],
                                    "destination": [
                                        "fw-mulneg1",
                                        0
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-phasor",
                                        0
                                    ],
                                    "destination": [
                                        "fw-mul02",
                                        0
                                    ],
                                    "order": 2
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-phasor",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minB",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-ovscale",
                                        0
                                    ],
                                    "destination": [
                                        "fw-downsum",
                                        1
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-outscale",
                                        0
                                    ],
                                    "destination": [
                                        "fw-out",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-onepole",
                                        0
                                    ],
                                    "destination": [
                                        "fw-highpass-sub",
                                        1
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mulneg1",
                                        0
                                    ],
                                    "destination": [
                                        "fw-add1",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mul6",
                                        0
                                    ],
                                    "destination": [
                                        "fw-sub05",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mul2shape",
                                        0
                                    ],
                                    "destination": [
                                        "fw-up",
                                        0
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mul2shape",
                                        0
                                    ],
                                    "destination": [
                                        "fw-down",
                                        0
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-mul02",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minA",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-minC",
                                        0
                                    ],
                                    "destination": [
                                        "fw-mul6",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-minB",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minC",
                                        1
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-minA",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minC",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-highpass-sub",
                                        0
                                    ],
                                    "destination": [
                                        "fw-outscale",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-freq-in",
                                        0
                                    ],
                                    "destination": [
                                        "fw-phasor",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-downsum",
                                        0
                                    ],
                                    "destination": [
                                        "fw-sum",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-down",
                                        0
                                    ],
                                    "destination": [
                                        "fw-resmul",
                                        1
                                    ],
                                    "order": 1
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-down",
                                        0
                                    ],
                                    "destination": [
                                        "fw-downsum",
                                        0
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-div100",
                                        0
                                    ],
                                    "destination": [
                                        "fw-resmul",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-cos",
                                        0
                                    ],
                                    "destination": [
                                        "fw-ovscale",
                                        0
                                    ]
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-add1",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minB",
                                        1
                                    ],
                                    "order": 0
                                }
                            },
                            {
                                "patchline": {
                                    "source": [
                                        "fw-add1",
                                        0
                                    ],
                                    "destination": [
                                        "fw-minA",
                                        1
                                    ],
                                    "order": 1
                                }
                            }
                        ]
                    },
                    "saved_object_attributes": {
                        "description": "Farnell housefly wing",
                        "digest": "Max translation of Designing Sound Fig. 50.13",
                        "tags": "fly insect Farnell"
                    }
                }
            },
            {
                "box": {
                    "maxclass": "comment",
                    "text": "wing 1",
                    "patching_rect": [
                        145.37814259529114,
                        461.34451031684875,
                        130.0,
                        20.0
                    ],
                    "numinlets": 1,
                    "id": "wing1-label",
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "comment",
                    "text": "wing 2 (+ slight detune)",
                    "patching_rect": [
                        395.79829573631287,
                        461.34451031684875,
                        133.0,
                        20.0
                    ],
                    "numinlets": 1,
                    "id": "wing2-label",
                    "numoutlets": 0
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "+~",
                    "patching_rect": [
                        290.7562851905823,
                        515.9663558006287,
                        40.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "sum-wings",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "text": "*~ 0.3",
                    "patching_rect": [
                        290.7562851905823,
                        556.3024878501892,
                        52.0,
                        22.0
                    ],
                    "outlettype": [
                        "signal"
                    ],
                    "numinlets": 2,
                    "id": "master-scale",
                    "numoutlets": 1
                }
            },
            {
                "box": {
                    "maxclass": "outlet",
                    "patching_rect": [
                        290.7562851905823,
                        638.655424118042,
                        30.0,
                        30.0
                    ],
                    "numinlets": 1,
                    "id": "obj-119",
                    "numoutlets": 0,
                    "comment": "",
                    "index": 1
                }
            },
            {
                "box": {
                    "maxclass": "comment",
                    "patching_rect": [
                        690.0,
                        92.0,
                        300.0,
                        34.0
                    ],
                    "id": "turn-comment",
                    "text": "NEU: Wendungsst\u00e4rke 0..1 moduliert nur den kleinen Frequenzoffset von Fl\u00fcgel 2.",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "linecount": 2
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        690.0,
                        135.0,
                        145.0,
                        22.0
                    ],
                    "id": "turn-recv",
                    "text": "receive #1_Turnmapping",
                    "numinlets": 0,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        690.0,
                        170.0,
                        72.0,
                        22.0
                    ],
                    "id": "turn-clip",
                    "text": "clip 0. 1.",
                    "numinlets": 3,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        690.0,
                        205.0,
                        130.0,
                        22.0
                    ],
                    "id": "turn-scale",
                    "text": "scale 0. 1. 0. 1.",
                    "numinlets": 6,
                    "numoutlets": 1,
                    "outlettype": [
                        ""
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "flonum",
                    "patching_rect": [
                        835.0,
                        205.0,
                        72.0,
                        22.0
                    ],
                    "id": "turn-num",
                    "numinlets": 1,
                    "numoutlets": 2,
                    "outlettype": [
                        "",
                        "bang"
                    ],
                    "parameter_enable": 0,
                    "format": 6
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        690.0,
                        240.0,
                        31.0,
                        22.0
                    ],
                    "id": "turn-sig",
                    "text": "sig~",
                    "numinlets": 1,
                    "numoutlets": 1,
                    "outlettype": [
                        "signal"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        690.0,
                        275.0,
                        142.0,
                        22.0
                    ],
                    "id": "turn-smooth",
                    "text": "rampsmooth~ 480 2400",
                    "numinlets": 3,
                    "numoutlets": 1,
                    "outlettype": [
                        "signal"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "newobj",
                    "patching_rect": [
                        505.0,
                        253.0,
                        40.0,
                        22.0
                    ],
                    "id": "turn-add",
                    "text": "+~",
                    "numinlets": 2,
                    "numoutlets": 1,
                    "outlettype": [
                        "signal"
                    ]
                }
            },
            {
                "box": {
                    "maxclass": "comment",
                    "patching_rect": [
                        690.0,
                        310.0,
                        330.0,
                        47.0
                    ],
                    "id": "turn-note",
                    "text": "1.0 am scale-Ausgang = maximal +1 Hz zus\u00e4tzlicher Detune bei einer 180\u00b0-Umkehr. Diesen Maximalwert sp\u00e4ter nach Geh\u00f6r/Messung anpassen.",
                    "numinlets": 1,
                    "numoutlets": 0,
                    "linecount": 3
                }
            }
        ],
        "lines": [
            {
                "patchline": {
                    "source": [
                        "wing2",
                        0
                    ],
                    "destination": [
                        "sum-wings",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "wing1",
                        0
                    ],
                    "destination": [
                        "sum-wings",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "sum-wings",
                        0
                    ],
                    "destination": [
                        "master-scale",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "res-depth",
                        0
                    ],
                    "destination": [
                        "res-base",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "res-base",
                        0
                    ],
                    "destination": [
                        "obj-17",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-6",
                        0
                    ],
                    "destination": [
                        "obj-10",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-3",
                        0
                    ],
                    "destination": [
                        "obj-2",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-2",
                        0
                    ],
                    "destination": [
                        "freq-base",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-17",
                        0
                    ],
                    "destination": [
                        "wing2",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-17",
                        0
                    ],
                    "destination": [
                        "wing1",
                        0
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-14",
                        0
                    ],
                    "destination": [
                        "obj-17",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-13",
                        0
                    ],
                    "destination": [
                        "obj-14",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-11",
                        0
                    ],
                    "destination": [
                        "obj-13",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "obj-10",
                        0
                    ],
                    "destination": [
                        "obj-11",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "noise-res",
                        0
                    ],
                    "destination": [
                        "lp5a",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "noise-freq",
                        0
                    ],
                    "destination": [
                        "lp4a",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "master-scale",
                        0
                    ],
                    "destination": [
                        "obj-119",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "lp5b",
                        0
                    ],
                    "destination": [
                        "res-depth",
                        0
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "lp5b",
                        0
                    ],
                    "destination": [
                        "offset-depth",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "lp5a",
                        0
                    ],
                    "destination": [
                        "lp5b",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "lp4b",
                        0
                    ],
                    "destination": [
                        "freq-depth",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "lp4a",
                        0
                    ],
                    "destination": [
                        "lp4b",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "freq2-sum",
                        0
                    ],
                    "destination": [
                        "wing2",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "freq-depth",
                        0
                    ],
                    "destination": [
                        "freq-base",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "freq-base",
                        0
                    ],
                    "destination": [
                        "wing1",
                        1
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "freq-base",
                        0
                    ],
                    "destination": [
                        "freq2-sum",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-recv",
                        0
                    ],
                    "destination": [
                        "turn-clip",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-clip",
                        0
                    ],
                    "destination": [
                        "turn-scale",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-scale",
                        0
                    ],
                    "destination": [
                        "turn-num",
                        0
                    ],
                    "order": 1
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-scale",
                        0
                    ],
                    "destination": [
                        "turn-sig",
                        0
                    ],
                    "order": 0
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-sig",
                        0
                    ],
                    "destination": [
                        "turn-smooth",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "offset-depth",
                        0
                    ],
                    "destination": [
                        "turn-add",
                        0
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-smooth",
                        0
                    ],
                    "destination": [
                        "turn-add",
                        1
                    ]
                }
            },
            {
                "patchline": {
                    "source": [
                        "turn-add",
                        0
                    ],
                    "destination": [
                        "freq2-sum",
                        1
                    ]
                }
            }
        ]
    }
}